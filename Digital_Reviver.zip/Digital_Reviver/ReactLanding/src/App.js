import React, { useState , useEffect } from "react";
import Navbar from "./Components/Navbar/navbar";
//import Footer from "./Components/Footer/footer";
import Home from "./Components/Home/home";
import Popup from "./Components/Popup/popup";
import FloatingSocialIcons from "./Components/FloatingSocialIcons/FloatingSocialIcons";
import About from "./Components/About/about";
import Dashboard from "./Components/Dashboard/dashboard";
import Login from "./Components/Login/login";
import PopupList from "./Components/PopupList/popupList";
import Cards from "./Components/Cards/cards";
import ContactQuery from "./Components/ContactQuery/contactquery";
import Vision from "./Components/Vision/visionMision";
import Register from "./Components/Register/register";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dedicated from "./Components/Dedicated/dedicated";
import Courses from "./Components/Courses/courses";
import WhyChooseUs from "./Components/WhyChooseUs/whychooseus";
import Testimonials from "./Components/Testimonials/testimonials";
import Services from "./Components/Dedicated/dedicated";
import ContactUs from "./Components/ContactUs/contactsection";
import WhyChooseServices from "./Components/WhyChooseServices/whychoose";
import TestimonialSlider from "./Components/TestimonialsSlider/testimonialsslider";
import Blog from "./Components/Blog/blog";
import Footer from "./Components/Footer/footer";
import "./App.css"; // Import global styles

const App = () => {
  const [popupVisible, setPopupVisible] = useState(false);

  useEffect(() => {
    // Automatically open the popup after 3 seconds on page load
    const timer = setTimeout(() => {
      setPopupVisible(true);
    }, 3000);

    return () => clearTimeout(timer); // Cleanup function
  }, []);

  const openPopup = () => {
    console.log("Opening popup..."); // Debugging: Check if this runs
    setPopupVisible(true);
  };

  const closePopup = () => {
    console.log("Closing popup..."); // Debugging: Check if this runs
    setPopupVisible(false);
  };

  
  
  return (
    <Router>
    <Navbar openPopup={openPopup} />
   
    {/* Page Routes */}
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/" element={<Home />} />
        <Route path="/floating" element={<FloatingSocialIcons />} />
        <Route path="/about" element={<About />} />
        <Route path="/cards" element={<Cards />} />
        <Route path="/contactquery" element={<ContactQuery />} />
        <Route path="/vision" element={<Vision />} />
        <Route path="/dedicated" element={<Dedicated />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/popuplist" element={<PopupList />} />
        <Route path="/chooseus" element={<WhyChooseUs />} />
        <Route path="/testimonials" element={<Testimonials />} />
        <Route path="/services" element={<Services />} />
        <Route path="/contactus" element={<ContactUs/>} />
        <Route path="/whychooseservices" element={<WhyChooseServices />} />
        <Route path="/testimonialsslider" element={<TestimonialSlider />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/footer" element={<Footer />} />
      </Routes>

      {popupVisible && <Popup closePopup={closePopup} />}
    </Router>
  );
};


export default App;

