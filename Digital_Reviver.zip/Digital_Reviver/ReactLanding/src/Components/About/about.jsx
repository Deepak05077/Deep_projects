import React from "react";
import "./about.css";
import image1 from "../Assets/images/office1.jpg"; // Ensure correct path
import image2 from "../Assets/images/office2.jpg"; // Ensure correct path
import Vision from "../Vision/visionMision";


const About = () => {
  return (
    <>
    <section className="about-section">
      <div className="about-content">
        <div className="rating">
          <span className="badge">Rated 4.9 of 5</span>
          <span className="stars">★★★★★</span>
        </div>
        <h2>About Us</h2>
        <p>
          Digital Reviver is one of the best digital marketing training institutes and agencies in India that covers all the major aspects of Digital Marketing, including Content Writing, SEO, Facebook Ads, Automation, and much more!
        </p>
        <p>
          With over 5 years of experience,  Digital Reviver is a leading digital marketing agency in Prayagraj. We are a full-service agency offering 360-degree digital marketing services such as SEO, social media, digital advertising, content, website design, and development.
        </p>
        <button className="read-more">Read More..</button>
      </div>
      <div className="about-images">
        <img src={image1} alt="Training session" className="images image1" />
        <img src={image2} alt="Classroom discussion" className="images image2" />
      </div>
    </section>



    <Vision />

    </>
  );
};

export default About;
