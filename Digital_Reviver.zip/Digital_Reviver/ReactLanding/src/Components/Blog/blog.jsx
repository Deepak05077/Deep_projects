import React, { useState, useEffect } from "react";
import "./blog.css";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";
import img1 from "../Assets/images/5.jpg";
import img2 from "../Assets/images/6.jpg";
import img3 from "../Assets/images/7_digital_skills600x387.png";
import img4 from "../Assets/images/blog4.jpg";
import img5 from "../Assets/images/blog5.jpg";
import Footer from "../Footer/footer";

const blogPosts = [
  {
    title: "The Rise of AI in Digital Marketing: How Artificial Intelligence is Shaping the Future",
    category: "Search Engine Optimization",
    date: "August 6, 2024",
    image:  img1,
  },
  {
    title: "AI in Education: Elevating Learning through Technology",
    category: "Search Engine Optimization",
    date: "November 6, 2024",
    image: img2 ,
  },
  {
    title: "Artificial Intelligence Content Generated for Search Engine Optimization (SEO)",
    category: "Search Engine Optimization",
    date: "October 23, 2024",
    image: img3 ,
  },
  {
    title: "Revolutionizing Business Strategies with AI-driven Analytics",
    category: "Artificial Intelligence",
    date: "December 10, 2024",
    image: img4 ,
  },
  {
    title: "AI-Powered Chatbots: Transforming Customer Service Experience",
    category: "Technology",
    date: "January 15, 2025",
    image: img5 ,
  },
];

const Blog = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const itemsPerPage = 3;

  const prevSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? blogPosts.length - itemsPerPage : prevIndex - 1
    );
  };

  const nextSlide = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex >= blogPosts.length - itemsPerPage ? 0 : prevIndex + 1
    );
  };

  // Auto slide every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <>
    <br/>
    <br/>
    <div className="blog-section">
      <div className="highlight">Latest Updates</div>
      <h1 className="blog-h1">Read From The Blog</h1>
      <p className="subtext">
        In this extremely competitive era, gain your competitive edge over your competition by reading and following our blogs!
      </p>
      <div className="divider">
        <span></span>
        <div className="arrow-down"></div>
        <span></span>
      </div>

      <div className="slider-container">
        <button className="nav-btn left" onClick={prevSlide}>
          <FaArrowLeft />
        </button>

        <div className="blog-wrapper">
          {blogPosts.slice(currentIndex, currentIndex + itemsPerPage).map((post, index) => (
            <div key={index} className="blog-card">
              <img src={post.image} alt={post.title} className="blog-image" />
              <span className="category">{post.category}</span>
              <h3>{post.title}</h3>
              <p className="date">📅 {post.date}</p>
            </div>
          ))}
        </div>

        <button className="nav-btn right" onClick={nextSlide}>
          <FaArrowRight />
        </button>
      </div>

      <div className="dots">
        {Array.from({ length: Math.ceil(blogPosts.length / itemsPerPage) }).map((_, index) => (
          <span
            key={index}
            className={`dot ${index === Math.floor(currentIndex / itemsPerPage) ? "active" : ""}`}
          ></span>
        ))}
      </div>
    </div>

    <Footer />
    </>
  );
};

export default Blog;
