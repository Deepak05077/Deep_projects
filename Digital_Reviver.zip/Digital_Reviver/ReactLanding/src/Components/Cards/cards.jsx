import React from "react";
import img1 from "../Assets/images/men face.jpg"
import img2 from "../Assets/images/female.jpg"
import "./cards.css"; 
import ContactQuery from "../ContactQuery/contactquery";

const Cards = () => {

   return (
    <>
    <div className="cards-container">
      <div className="card">
        <div className="card-content">
          <h3>For Courses</h3>
          <p>Ready to build your career in Digital Marketing?</p>
          {/* <button className="bttnn bttnn-orange hre">View Courses &rarr;</button> */}
          <a href="/Courses" className="bttnn bttnn-orange hre">View Courses &rarr;</a>
         

        </div>
        <div className="card-image">
          <img
            src={img1} // Replace with actual image
            alt="For Courses"
          />
          <div className="bg-shape bg-green"></div>
        </div>
      </div>

      <div className="card">
        <div className="card-content">
          <h3>For Services</h3>
          <p>Ready to grow your business online?</p>
          {/* <button className="bttnn bttnn-blue">View Services &rarr;</button> */}
          <a href="/services" className="bttnn bttnn-blue">View Services &rarr;</a>
        </div>
        <div className="card-image">
          <img
            src={img2} // Replace with actual image
            alt="For Services"
          />
          <div className="bg-shape bg-orange"></div>
        </div>
      </div>
    </div>

    <ContactQuery /> 
   </> 
  );
};

export default Cards;
