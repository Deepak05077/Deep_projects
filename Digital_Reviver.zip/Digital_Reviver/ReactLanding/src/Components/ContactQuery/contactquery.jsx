import React, { useState } from "react";
import "./contactquery.css";
import { FaPhoneAlt } from "react-icons/fa";
import Courses from "../Courses/courses";
import Popup from "../Popup/popup"; // Import Popup Component

const ContactQuery = () => {
  const phoneNumber = "9454033304";
  const [showPopup, setShowPopup] = useState(false);

  // Open Popup
  const openPopup = () => setShowPopup(true);
  
  // Close Popup
  const closePopup = () => setShowPopup(false);

  return (
    <>
      <div className="query-container">
        <h2>Do you have any query?</h2>
        <p>We will be more than happy to be of help to you!</p>

        {/* Contact Button */}
        <button className="contact-btnn" onClick={openPopup}>
          <FaPhoneAlt /> Contact Us
        </button>

        {/* Open Popup Form Button */}
        {/* <button className="query-btn" onClick={openPopup}>
          Open Contact Form
        </button> */}
      </div>

      {/* Show Popup if true */}
      {showPopup && <Popup closePopup={closePopup} />}

      <Courses />
    </>
  );
};

export default ContactQuery;
