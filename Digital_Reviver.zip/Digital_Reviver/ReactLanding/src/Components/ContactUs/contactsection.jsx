import React, { useState } from "react";
import axios from "axios";
import "./contactsection.css";
import { FaWhatsapp, FaPhoneAlt } from "react-icons/fa";
import WhyChooseServices from "../WhyChooseServices/whychoose";

const ContactSection = () => {
  const phoneNumber = "9454033304"; // Replace with actual phone number

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [responseMessage, setResponseMessage] = useState("");
  const [loading, setLoading] = useState(false);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResponseMessage("");

    try {
      const response = await axios.post("http://localhost:8080/popup", formData);
      alert(response.data.message);
      setFormData({ name: "", email: "", phone: "", message: "" }); // Reset form
    } catch (error) {
      alert("Failed to send message");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <section className="contact-section">
        <h2>Ready to Grow Your Business?</h2>
        <div className="contact-buttons">
          <a href={`tel:${phoneNumber}`} className="bttn call-btn">
            <FaPhoneAlt /> Get Free Proposals
          </a>
          <span className="or">Or</span>
          <a
            href={`https://wa.me/${phoneNumber}`}
            target="_blank"
            rel="noopener noreferrer"
            className="bttn whatsapp-btn"
          >
            <FaWhatsapp /> {phoneNumber}
          </a>
        </div>
      </section>

      {/* Contact Us Section */}
      <section id="ContactUs" className="fifth-section">
        <section className="contact-section2">
          <h2 className="contact-title">--------------------Contact Us---------------------</h2>
          <h3 className="office-location">Our Office Location</h3>
          <ul className="contact-info">
                <li>📍 Address: A44 Sector-2 Near Sector 15 Metro Station</li>
                <li>📞 Phone: +91 9454033304</li>
                <li>✉ Gmail: info.digitalreviver585@gmail.com</li>
              </ul>
          <p className="contact-desc">Welcome to Digital Reviver. We are glad to hear from you.</p>

          <div className="contact-container">
            {/* Left Side: Google Map & Address */}
            <div className="contact-left">
              <iframe
                title="Google Map - Digital Reviver Office Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.474377882032!2d77.30979527616309!3d28.585542386211714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce52dd3c61e33%3A0x9d4284dae84aa42!2sVDS!5e0!3m2!1sen!2sin!4v1739961453326!5m2!1sen!2sin"
                width="480"
                height="440"
                style={{ border: "0" }}
                allowFullScreen=""
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
           
            </div>

            {/* Right Side: Contact Form */}
            <div className="contact-right">
              <form onSubmit={handleSubmit}>
                <label htmlFor="name">Your Name:</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  placeholder="Name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />

                <label htmlFor="email">Your Email:</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />

                <label htmlFor="phone">Your Phone Number:</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  placeholder="Phone Number"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />

                <label htmlFor="message">Your Message:</label>
                <textarea
                  id="message"
                  name="message"
                  placeholder="Message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                ></textarea>

                <button type="submit" disabled={loading}>
                  {loading ? "Sending..." : "Send"}
                </button>
              </form>
            </div>
          </div>
        </section>
      </section>
      {responseMessage && <p className="response-message">{responseMessage}</p>}

      <WhyChooseServices />
    </>
  );
};

export default ContactSection;
