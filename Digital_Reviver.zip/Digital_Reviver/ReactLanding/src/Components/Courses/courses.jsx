import React from "react";
import "./courses.css";
import WhyChooseUs from "../WhyChooseUs/whychooseus";

const Courses = () => {
  return (

    <>
    <br/>
    <div className="c-container">
      {/* Header Section */}
      <div className="header">
        <span className="badge">Most Popular Courses</span>
        <h1  className="badge-h1">Digital Reviver Digital Marketing Courses</h1>
        <p className="badge-p">Digital Reviver provides value-for-money courses which you can afford at the best price in the market.</p>
        <div className="divider"></div>
      </div>

      {/* Course Cards */}
      <div className="courses">
        <div className="course-card blue">
          <span className="span">Most Popular</span>
          <h2 className="courses-h2">Advance Digital Marketing Course</h2>
          <a href="#">Check it out →</a>
        </div>

        <div className="course-card orange">
          <span className="span">Most Popular</span>
          <h2 className="courses-h2">Beginner’s Digital Marketing Course</h2>
          <a href="#">Check it out →</a>
        </div>

        <div className="course-card teal">
          <span className="span">Most Popular</span>
          <h2 className="courses-h2">Digital Marketing Short Term Course</h2>
          <a href="#">Check it out →</a>
        </div>
      </div>
      <div className="dm-info">
          <div className="dm-info-item">
            <span>💰</span>
            <p>Classes by industry experts and doubt clearing feedback sessions after every class</p>
          </div>
          <div className="dm-info-item">
            <span>🛠</span>
            <p>Access to premium tools and digital marketing course materials</p>
          </div>
          <div className="dm-info-item">
            <span>📌</span>
            <p>Practical learning based on implementation and opportunity to work on live projects</p>
          </div>
          <div className="dm-info-item">
            <span>🤝</span>
            <p>Supportive and conducive atmosphere for students to help them become an all-rounded individual</p>
          </div>
        </div>
    </div>
    <WhyChooseUs />
    </>
  );
};

export default Courses;
