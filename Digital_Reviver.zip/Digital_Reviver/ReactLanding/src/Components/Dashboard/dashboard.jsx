import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./dashboard.css";

const Dashboard = () => {
  const [popups, setPopups] = useState([]);
  const navigate = useNavigate();
  
  // Ensure token is retrieved correctly
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!token) {
      navigate("/login"); // Redirect if not logged in
      return;
    }

    fetch("http://localhost:8080/admin/popups", {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    })
      .then((res) => {
        if (!res.ok) {
          throw new Error("Unauthorized or Server Error");
        }
        return res.json();
      })
      .then((data) => setPopups(data))
      .catch((err) => console.error("Error:", err));
  }, [token, navigate]); // Include dependencies

  const handleDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        navigate("/login");
        return;
      }

      await axios.delete(`http://localhost:8080/admin/popup/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setPopups(popups.filter((popup) => popup._id !== id));
    } catch (err) {
      console.error("Error deleting popup:", err);
    }
  };

  return (
    <div className="dashboard-container">
      <h2>Admin Dashboard</h2>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Message</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {popups.map((popup) => (
            <tr key={popup._id}>
              <td>{popup.name}</td>
              <td>{popup.email}</td>
              <td>{popup.phone}</td>
              <td>{popup.message}</td>
              <td>
                <button className="delete-btn" onClick={() => handleDelete(popup._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button className="btn" onClick={() => { localStorage.removeItem("token"); navigate("/login"); }}>Logout</button>
    </div>
  );
};

export default Dashboard;
