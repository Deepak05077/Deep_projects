import React from "react";
import "./dedicated.css"; // Import the CSS file
import Cards from "../Cards/cards";

const Services = () => {
  return (
    <>
    <br/>
    <br/>
    <div className="contain">
      <span className="badge">World-class Quality</span>
      <h2 className="title">
        Dedicated courses and services for students and businesses
      </h2>
      <p className="description">
        We pride ourselves on offering best courses to our students and
        remarkable marketing results to our clients.
      </p>
      <div className="divider">
        <span className="triangle"></span>
      </div>
    </div>
    
   <Cards />
    </>
  );
};

export default Services;
