import React from "react";
import { FaWhatsapp, FaInstagram, FaPhoneAlt } from "react-icons/fa";
import "./FloatingSocialIcons.css"; // Import CSS

const FloatingSocialIcons = () => {
  return (
    <div className="social-icons-container">
      <a
        href="https://wa.me/9454033304"
        target="_blank"
        rel="noopener noreferrer"
        className="social-icon whatsapp"
      >
        <FaWhatsapp />
      </a>
      <a
        href="https://www.instagram.com/digitalreviver123/"
        target="_blank"
        rel="noopener noreferrer"
        className="social-icon instagram"
      >
        <FaInstagram />
      </a>
      <a href="tel:+91-9454033304" className="social-icon contact">
        <FaPhoneAlt />
      </a>
    </div>
  );
};

export default FloatingSocialIcons;
