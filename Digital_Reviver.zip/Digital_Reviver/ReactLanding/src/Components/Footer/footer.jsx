import React from "react";
import "./footer.css"; // Import the CSS file
import img from "../Assets/images/logo2.png"
import { FaLinkedin, FaTwitter, FaInstagram, FaFacebook, FaWhatsapp } from "react-icons/fa";
import { MdAccessTime, MdLocationOn, MdEmail, MdPhone } from "react-icons/md";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        {/* Left Section - Logo & About */}
        <div className="footer-left">
          <img src={img} alt="digital Reviver Logo" className="footer-logo" />
          <p>
            We are India-based Digital Marketing Institute & Agency, focusing on providing the best Digital Marketing Training and Services.
          </p>
          <p className="follow-us">Follow us on</p>
          <div className="social-icons">
            <a href="https://www.linkedin.com/in/digital-reviver-b35034355/" target="_blank" rel="noopener noreferrer">
              <FaLinkedin />
            </a>
            <a href="https://x.com/DReviver27038" target="_blank" rel="noopener noreferrer">
              <FaTwitter />
            </a>
            <a href="https://www.instagram.com/digitalreviver123/" target="_blank" rel="noopener noreferrer">
              <FaInstagram />
            </a>
            <a href="https://www.facebook.com/pages/creation/?ref_type=comet_home" target="_blank" rel="noopener noreferrer">
              <FaFacebook />
            </a>
            <a href="https://wa.me/9454033304" target="_blank" rel="noopener noreferrer">
              <FaWhatsapp />
            </a>
          </div>
        
        </div>

        {/* Middle Section - Links */}
        <div className="footer-links">

          
          <h4>Important Link</h4>
          <ul>
            <li>Home</li>
            <li>About Us</li>
            <li>Courses</li>
            <li>Contact Us</li>
            <li>Careers</li>
          </ul>
        </div>

        <div className="footer-links">
          <h4>Services</h4>
          <ul>
            <li>Digital Marketing</li>
            <li>Website Development</li>
            <li>App Development</li>
            <li>Google Ads</li>
            <li>Social Media Marketing</li>
          </ul>
        </div>

        {/* Right Section - Contact Information */}
        <div className="footer-info">
          <h4>Useful Information</h4>
          <p><MdAccessTime /> Open 9:00am to 6:00pm, Monday to Saturday</p>
          <p><MdLocationOn /> VDS  ,    A44 , 4th Floor, Sector-2 Noida </p>
          <p><MdEmail /> <a href="mailto:info.digitalreviver585@gmail.com">info.digitalreviver585@gmail.com</a></p>
          <p><MdPhone /><a href="tel:+91-9454033304"> +91-9454033304</a></p>
        </div>
      </div>

      <div className="footer-bottom">
        Powered by Digital Reviver © All rights reserved
      </div>
    </footer>
  );
};

export default Footer;
