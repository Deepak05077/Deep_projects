import React from "react";
import "./home.css"; // Import Home section CSS
import About from "../About/about";
import FloatingSocialIcons from "../FloatingSocialIcons/FloatingSocialIcons";

const Home = () => {
  return (
    <>
    <section className="home">
      <div className="home-content">
        <h1>Welcome to Our Website <br />
        <span>Digital Reviver</span> 
        <span className="span2"></span></h1>
        <p>Your trusted partner for digital solutions.</p>
      </div>
    </section>

    <About  />
    <FloatingSocialIcons />
    </>
  );
};

export default Home;
