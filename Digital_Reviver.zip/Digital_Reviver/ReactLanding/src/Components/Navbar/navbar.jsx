import React from "react";
import "./navbar.css"; 
import logo from "../Assets/images/logo2.png"; // Ensure correct path
import { useState, useEffect } from "react";

const Navbar = ({ openPopup }) => {
  const [scrolling, setScrolling] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolling(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
<>
    <header className={`navbar ${scrolling ? "scrolled" : ""}`}>
      {/* Logo */}
      <div className="logo">
        <img src={logo} alt="logo" />
      </div>
     {/* Navigation Links */}
     <nav className={`nav-menu ${menuOpen ? "open" : ""}`}>
        <ul className="nav-links">
          <li><a href="/">Home</a></li>
          <li><a href="/about">About Us</a></li>
          <li><a href="/Services">Services</a></li>
          <li><a href="/blog">Blog</a></li>
          <li><a href="/contactus">Contact Us</a></li>
        </ul>
      </nav>
        {/* Contact Button */}
      {/* Ensure the button triggers the popup */}
      <button className="contact-btnnn" onClick={openPopup}>
        Contact with Us
      </button>
     {/* Menu Toggle Button (For Mobile) */}
     <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
        ☰
      </button>

    </header>
    
    </>


  );
};

export default Navbar;
