import React from "react";
import "./footer.css";
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>



const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">
        {/* Social Media Links */}
        <div className="social">
          <span>Follow us on</span>
          <a href="#"><i className="fab fa-facebook-f"></i></a>
          <a href="#"><i className="fab fa-twitter"></i></a>
          <a href="#"><i className="fab fa-linkedin-in"></i></a>
          <a href="#"><i className="fab fa-instagram"></i></a>
          <a href="#"><i className="fab fa-whatsapp"></i></a>
        </div>
        
        {/* Contact Email */}
        <div className="contact">
          <i className="fas fa-envelope"></i>
          <span>✉️ Contact us <a href="mailto:infodigitalreviver@gmail.com">info.digitalreviver@gmail.com</a></span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
