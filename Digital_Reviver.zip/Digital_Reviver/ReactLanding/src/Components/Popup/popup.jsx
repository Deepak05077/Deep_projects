import React from "react";
import axios from "axios";
import { useState } from "react";
import "./popup.css"; // Import Popup CSS

const Popup = ({ closePopup }) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const [responseMessage, setResponseMessage] = useState("");
  const [loading, setLoading] = useState(false);
  // console.log("Current Form State:", formData);

  // Handle input change
  const handleChange = (e) => {
    // console.log("Typing in Input:", e.target.name, "=", e.target.value);
    const { name, value } = e.target;
    // console.log(`Typing: ${name} = ${value}`);
    setFormData((prevData) => ({
      ...prevData,
      [name]: value, // Update the correct field
    }));
    // console.log("Updated State:", formData);
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true); // Start loading
    setResponseMessage("");

    try {
      // console.log("Submitting Data:", formData); //
      const response = await axios.post(
        "http://localhost:8080/popup",
        formData 
      );
      // console.log("Response:", response.data);
      setResponseMessage();
      alert(response.data.message);
      setFormData({ name: "", email: "", phone: "", message: "" }); // Reset form
    } catch (error) {
      console.error("Error:", error);
      setResponseMessage();
       alert("Failed to send message");
    } finally {
      setLoading(false); // Stop loading
    }
  };

  return (
    <div className="popup-overlay">
      <div className="popup-content">
        <span className="close-btn" onClick={closePopup}>
          &times;
        </span>
        <h2>Contact Us</h2>
        <form onSubmit={handleSubmit}>
          <label htmlFor="name">Your Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={handleChange}
            required
          />

          <label htmlFor="email">Your Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            placeholder="Email"
            value={formData.email}
            onChange={handleChange}
            required
          />

          <label htmlFor="phone">Your Phone Number:</label>
          <input
            type="tel"
            id="phone"
            name="phone"
            placeholder="Phone Number"
            value={formData.phone}
            onChange={handleChange}
            required
          />

          <label htmlFor="message">Your Message:</label>
          <textarea
            id="message"
            name="message"
            placeholder="Message"
            value={formData.message}
            onChange={handleChange}
            required
          />

          <button type="submit" disabled={loading}>
            {loading ? "Sending..." : "Send"} 
          </button>
        </form>
        {responseMessage && <p className="response-message">{responseMessage}</p>}
      </div>
    </div>
  );
};

export default Popup;
