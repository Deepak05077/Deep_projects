import { useEffect, useState } from "react";
import axios from "axios";

const PopupList = () => {
  const [popups, setPopups] = useState([]);

  useEffect(() => {
    const fetchPopups = async () => {
      try {
        const response = await axios.get("http://localhost:8080/popups");
        setPopups(response.data);
      } catch (error) {
        console.error("Error fetching popups:", error);
      }
    };
    fetchPopups();
  }, []);

  return (
    <div>
      <h2>Submitted Messages</h2>
      <ul>
        {popups.map((popup, index) => (
          <li key={index}>
            <p><strong>Name:</strong> {popup.name}</p>
            <p><strong>Email:</strong> {popup.email}</p>
            <p><strong>Phone:</strong> {popup.phone}</p>
            <p><strong>Message:</strong> {popup.message}</p>
            <hr />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default PopupList;
