import React, { useState , useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./register.css";

const Register = () => {
  const [username, setUsername] = useState("");
  //   const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();


  useEffect(() => {
    setUsername("");
    setPassword("");
  }, []);

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");

    try {
      const response = await axios.post(
        "http://localhost:8080/admin/register",
        { username, password }
      );
      alert("✅ Registration Successful! Redirecting to Login...");

        // **Clear input fields after successful registration**
        setUsername("");
        setPassword("");
  
        setTimeout(() => {
          navigate("/login");
        }, 800); // Redirect to login after registration

        console.log("✅ Registration successful:", response.data);
    } catch (err) {
      console.error("Registration error:", err.response?.data);
      setError(err.response?.data?.error || "Something went wrong");
    }
    
  };

  return (
    <div className="register-container">
      <h2>Register</h2>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleRegister}>
        <input
          type="text"
          placeholder="Username"
          value={username}
          
          onChange={(e) => {
            // console.log("Typing username:", e.target.value); // Debugging
            setUsername(e.target.value);
          }}
          autoComplete="off"
          required

         
        />
        {/* <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required /> */}
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => {
            // console.log("Typing password:", e.target.value); // Debugging
            setPassword(e.target.value);
          }}
            autoComplete="new-password"
          required
        />
        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default Register;
