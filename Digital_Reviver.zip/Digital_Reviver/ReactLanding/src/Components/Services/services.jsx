import React from "react";
import "./services.css";
import ContactSection from "../ContactUs/contactsection";
import img1 from "../Assets/images/3d-digital-marketing-manager-marketer-man-with-laptor-data-analysis_1239994-729.png";
import img2 from "../Assets/images/digital-marketing-email-marketing-3d-man-holding-megaphone-sending-email-letters-looking-graphs-managing.png";
import img3 from "../Assets/images/youtube5.jpg";

const services = [
  {
    title: "Social Media Marketing",
    description:
      "Unlock the power of social media with our comprehensive Social Media Marketing course.",
    image: img2, // Replace with actual image
    tag: "Most Popular",
  },
  {
    title: "Website Designing",
    description:
      "Discover the art of captivating web designs that boost audience engagement and success.",
    image: img1, // Replace with actual image
    tag: "Most Popular",
  },
  {
    title: "YouTube Marketing",
    description:
      "Our specialized course equips you with strategies to optimize your YouTube presence.",
    image: img3, // Replace with actual image
    tag: "Most Popular",
  },
];

const Services = () => {
  return (

    <>
    <div className="services-section">
      <div className="services-header">
        <h3>Most Popular Services</h3>
        <h1>Our Most Popular Digital Marketing Services</h1>
        <p>Explore a wide range of digital marketing services.</p>
      </div>

      <div className="services-container">
        {services.map((service, index) => (
          <div key={index} className="service-card">
            <img src={service.image} alt={service.title} className="service-img" />
            <span className="service-tag">{service.tag}</span>
            <h2>{service.title}</h2>
            <p>{service.description}</p>
            <button className="service-btn">Know More</button>
          </div>
        ))}
      </div>
    </div>
    <ContactSection />
    </>
  );
};

export default Services;
