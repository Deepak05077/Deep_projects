import React, { useRef } from "react";
import "./testimonials.css"; // Import CSS
import Services from "../Services/services";

const testimonials = [
  {
    name: "Shiven Singh",
    role: "Student, Digital Reviver",
    text: "I am very happy that I have taken the decision to learn Digital Marketing from Digital Reviver .The digital marketing course was well-structured and practical. I secured an internship right after completing my training, thanks to the expert guidance from Digital reviver...",
    img: "https://randomuser.me/api/portraits/men/1.jpg",
  },
  {
    name: "Abdul Haleem",
    role: "Student, Digital Reviver",
    text: "I came across Digital Reviver when I was looking for the best digital marketing institute in Noida. Digital Reviver provided an excellent learning environment! The mentors were always available, and the real-world projects helped me gain confidence that is required!...",
    img: "https://randomuser.me/api/portraits/men/2.jpg",
  },
  {
    name: "Medha Kesarwani",
    role: "Student, Digital Reviver",
    text: "I loved the hands-on approach at Digital Reviver. The interactive sessions and case studies helped me understand concepts deeply. This course gave me the edge I needed.which made all the difference in my learning experience! and   that means a lot  for all students!..",
    img: "https://randomuser.me/api/portraits/women/3.jpg",
  },
  {
    name: "Rahul Verma",
    role: "Student, Digital Reviver",
    text: "Digital Reviver' courses transformed my understanding of digital marketing. The lessons were invaluable.From beginner to expert in just a few months! Digital Reviver' structured approach and experienced trainers made learning digital marketing enjoyable and insightful...",
    img: "https://randomuser.me/api/portraits/men/4.jpg",
  },
  {
    name: "Neha Sharma",
    role: "Student, Digital Reviver",
    text: "Enrolling in Digital Reviver was the best decision! The hands-on approach to teaching made learning so effective.I used to struggle with job interviews, but Digital Reviver' placement support and mock interviews helped me land a great job. Forever grateful!",
    img: "https://randomuser.me/api/portraits/women/5.jpg",
  },
];

const Testimonials = () => {
    const scrollRef = useRef(null);
  
    const scroll = (direction) => {
      if (scrollRef.current) {
        const scrollAmount = 350 * 3; // Scroll by 3 cards width
        scrollRef.current.scrollBy({
          left: direction === "left" ? -scrollAmount : scrollAmount,
          behavior: "smooth",
        });
      }
    };
  
    return (

      <>
      <div className="testimonials-section">
        <p className="badge">Unlimited Possibilities</p>
        <h2 className="badge-heading">What our students said about us</h2>
        <div className="testimonials-container">
          <button className="nav-btn left" onClick={() => scroll("left")}>
            &lt;
          </button>
          <div className="testimonials-scroll" ref={scrollRef}>
            {testimonials.map((testimonial, index) => (
              <div key={index} className="testimonial-card">
                <p>"{testimonial.text}"</p>
                <div className="testimonial-user">
                  <img src={testimonial.img} alt={testimonial.name} />
                  <div>
                    <h4>{testimonial.name}</h4>
                    <p className="role">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button className="nav-btn right" onClick={() => scroll("right")}>
            &gt;
          </button>
        </div>
      </div>
      <Services  />
      </>
    );
};

export default Testimonials;
