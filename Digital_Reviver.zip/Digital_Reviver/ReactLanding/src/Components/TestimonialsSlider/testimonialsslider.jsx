import React from "react";
import "./testimonialsslider.css";
import { useState } from "react";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";
import BlogSlider from "../Blog/blog";

const testimonials = [
    {
      text: "We were truly impressed! Their social media marketing work is excellent. All the deliverables reached us on time. The marketing produced definitive results.",
      author: "Makoons",
    },
    {
      text: "Webpeckers has delivered great results with our digital marketing, leading to much increased revenue and profit. Our experience has been amazing!",
      author: "Shuchita Pharmacy",
    },
    {
      text: "Our online sales results have grown considerably. We find the skills that the agency holds incredibly valuable in helping us develop our online sales goals.",
      author: "Shuchita Prakashan",
    },
    {
      text: "The team is proactive, responsive, and results-oriented. We have seen an incredible improvement in our business performance since we started working with them.",
      author: "Digital Trends",
    },
    {
      text: "Exceptional service and creative marketing strategies. Our brand visibility has skyrocketed. Highly recommend their expertise!",
      author: "Innovate Tech",
    },
  ];
  
  const TestimonialSlider = () => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const itemsPerPage = 3;
  
    const prevTestimonial = () => {
      setCurrentIndex((prevIndex) =>
        prevIndex === 0 ? testimonials.length - itemsPerPage : prevIndex - 1
      );
    };
  
    const nextTestimonial = () => {
      setCurrentIndex((prevIndex) =>
        prevIndex >= testimonials.length - itemsPerPage ? 0 : prevIndex + 1
      );
    };
  
    return (
        <>
      <div className="testimonial-section">
        <div className="highlight">Unlimited Possibilities</div>
        <h1>What our clients said about us</h1>
  
        <div className="slider-container">
          <button className="nav-btn left" onClick={prevTestimonial}>
            <FaArrowLeft />
          </button>
  
          <div className="testimonial-wrapper">
            {testimonials.slice(currentIndex, currentIndex + itemsPerPage).map((testimonial, index) => (
              <div key={index} className="testimonial-cardd">
                <p className="testimonial-text">"{testimonial.text}"</p>
                <span className="testimonial-author">{testimonial.author}</span>
              </div>
            ))}
          </div>
  
          <button className="nav-btn right" onClick={nextTestimonial}>
            <FaArrowRight />
          </button>
        </div>
  
        <div className="dots">
          {Array.from({ length: Math.ceil(testimonials.length / itemsPerPage) }).map((_, index) => (
            <span
              key={index}
              className={`dot ${index === Math.floor(currentIndex / itemsPerPage) ? "active" : ""}`}
            ></span>
          ))}
        </div>
      </div>
      <BlogSlider  />
      </>
    );
};

export default TestimonialSlider;
