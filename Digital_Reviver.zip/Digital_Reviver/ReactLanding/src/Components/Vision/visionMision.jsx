import React, { useState } from "react";
import "./visionMision.css"; // Import the CSS file
import Dedicated from "../Dedicated/dedicated"; ///Import the Cards component

const Vision = () => {
    const [selected, setSelected] = useState("vision");
  
    return (
      <>
      
      <div className="container">
      <div className="button-group">
        <button
          className={`toggle-button ${selected === "vision" ? "active" : ""}`}
          onClick={() => setSelected("vision")}
        >
          ⚫ Our Vision
        </button>
        <button
          className={`toggle-button ${selected === "mission" ? "active" : ""}`}
          onClick={() => setSelected("mission")}
        >
          ⚫ Our Mission
        </button>
        <button
          className={`toggle-button ${selected === "values" ? "active" : ""}`}
          onClick={() => setSelected("values")}
        >
          ⚫ Our Values
        </button>
      </div>

      <div className="vision-content">
        {selected === "vision" && (
          <p>To create the largest conglomeration of digital marketing resources...</p>
        )}
        {selected === "mission" && <p>Our mission is to empower businesses through ...</p>}
        {selected === "values" && <p>We value innovation, integrity, and impact...</p>}
      </div>
    </div>
  <Dedicated />
      </>
    );
  };
export default Vision;
