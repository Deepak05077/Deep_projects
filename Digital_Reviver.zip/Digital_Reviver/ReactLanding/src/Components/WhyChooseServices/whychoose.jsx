import React from "react";
import "./whychoose.css";
import { FaCheck, FaUserFriends, FaChartLine } from "react-icons/fa"; // Importing icons
import TestimonialSlider from "../TestimonialsSlider/testimonialsslider";

const WhyChooseServices = () => {
  return (
    <>
    <section className="why-choose-us">
      <h3 className="highlight">World-class Quality</h3>
      <h1>Why Choose Our Services?</h1>
      <p className="subtext">
        We provide the best digital marketing services that your brand requires to take it to the next level.
      </p>
      <div className="dividerr">
        <span></span>
        <i className="arrow-down"></i>
        <span></span>
      </div>

      <div className="features">
        <div className="feature-boxx">
          <FaCheck className="icon" />
          <h3>Proven Methodology</h3>
          <p>
            Provides a roadmap for success, combining tested principles with adaptable strategies for achieving desired outcomes.
          </p>
        </div>

        <div className="feature-boxx">
          <FaUserFriends className="icon" />
          <h3>Dedicated Account Managers</h3>
          <p>
            Provide personalized support, ensuring student’s satisfaction through proactive assistance and tailored guidance.
          </p>
        </div>

        <div className="feature-boxx">
          <FaChartLine className="icon" />
          <h3>Analytics and Results</h3>
          <p>
            Illuminating trends and insights to drive informed decisions. Results validate strategies, affirming effectiveness and guiding future actions.
          </p>
        </div>
      </div>
    </section>

    <TestimonialSlider />
    </>
  );
};

export default WhyChooseServices;
