import React from "react";
import "./whychooseus.css";
import img1 from "../Assets/images/open-book.png";
import img2 from "../Assets/images/group.png";
import img3 from "../Assets/images/open-book.png";
import Testimonials from "../Testimonials/testimonials";

const WhyChooseUs = () => {
  return (

    <>
    <section className="why-choose-section">
      <div className="why-choose-container">
        {/* Header */}
        <div className="why-choose-header">
          <span className="why-choose-badge">World-class Quality</span>
          <h2>Why Choose Our Digital Marketing Course?</h2>
          <p>
            Digital Reviver provides value for money courses which you can afford at the best price in the market.
          </p>
          <div className="why-choose-divider"></div>
        </div>

        {/* Features */}
        <div className="why-choose-features">
          <div className="feature-itemm">
            <img src={img1} alt="Book Icon" />
            <h3>Work on Real-time Projects</h3>
            <p>
              Working on real-time projects with real clients will equip you with the various challenges of the industry.
            </p>
          </div>

          <div className="feature-itemm">
            <img src={img2} alt="Faculty Icon" />
            <h3>Learn from the Best Faculty</h3>
            <p>
              Learn from the best digital marketing practitioners and attend guest lectures that leave you with rich insights.
            </p>
          </div>

          <div className="feature-itemm">
            <img src={img3} alt="Placement Icon" />
            <h3>100% Placement Assistance</h3>
            <p>
              We at Digital Reviver help you prepare for interviews and get placed in the best companies to work for.
            </p>
          </div>
        </div>
      </div>
    </section>

    <Testimonials  />
    </>
  );
};

export default WhyChooseUs;
